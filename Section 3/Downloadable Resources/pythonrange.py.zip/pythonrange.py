
for n in range (2,101):
    print ('vlan' + (n))

